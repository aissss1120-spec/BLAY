package com.blay.assistant;
import android.app.*; import android.content.*; import android.media.*; import android.os.*; import android.speech.*; import android.speech.tts.TextToSpeech; import android.speech.RecognitionListener; import android.net.Uri; import java.util.*;
public class BlayStandbyService extends Service implements TextToSpeech.OnInitListener {
 SpeechRecognizer r; TextToSpeech t; Handler h=new Handler(Looper.getMainLooper()); boolean active;
 public void onCreate(){super.onCreate(); NotificationChannel c=new NotificationChannel("blay","BLAY",NotificationManager.IMPORTANCE_LOW); getSystemService(NotificationManager.class).createNotificationChannel(c); startForeground(21,new Notification.Builder(this,"blay").setContentTitle("BLAY aktif").setContentText("Menunggu perintah suara").setSmallIcon(android.R.drawable.ic_btn_speak_now).build()); t=new TextToSpeech(this,this);}
 public int onStartCommand(Intent i,int f,int id){active=true; listen(); return START_STICKY;}
 void listen(){if(!active||checkSelfPermission("android.permission.RECORD_AUDIO")!=0)return; if(r!=null)r.destroy(); r=SpeechRecognizer.createSpeechRecognizer(this); r.setRecognitionListener(new RecognitionListener(){
 public void onResults(Bundle b){ArrayList<String>a=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); if(a!=null&&!a.isEmpty()) handle(a.get(0)); h.postDelayed(()->listen(),500);}
 public void onError(int e){h.postDelayed(()->listen(),1000);} public void onReadyForSpeech(Bundle x){} public void onBeginningOfSpeech(){} public void onRmsChanged(float x){} public void onBufferReceived(byte[]x){} public void onEndOfSpeech(){} public void onPartialResults(Bundle x){} public void onEvent(int x,Bundle y){}
 }); Intent x=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); x.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"id-ID"); x.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); r.startListening(x);}
 void handle(String s){String q=s.toLowerCase(Locale.ROOT).trim(); if(q.contains("youtube")){open("https://www.youtube.com/"); speak("Membuka YouTube");} else if(q.contains("maps")||q.contains("peta")){open("https://www.google.com/maps/"); speak("Membuka Maps");} else if(q.startsWith("buka ")){open("https://www.google.com/search?q="+Uri.encode(q.substring(5)));} else speak("Saya mendengar: "+s);}
 void open(String u){try{Intent x=new Intent(Intent.ACTION_VIEW,Uri.parse(u));x.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(x);}catch(Exception e){}}
 void speak(String s){if(t!=null)t.speak(s,TextToSpeech.QUEUE_FLUSH,null,"blay");}
 public void onInit(int x){}
 public IBinder onBind(Intent i){return null;}
 public void onDestroy(){active=false;if(r!=null)r.destroy();if(t!=null)t.shutdown();super.onDestroy();}
}
