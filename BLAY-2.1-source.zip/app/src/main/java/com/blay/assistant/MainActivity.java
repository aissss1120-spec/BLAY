package com.blay.assistant;
import android.Manifest; import android.app.Activity; import android.content.Intent; import android.content.pm.PackageManager; import android.os.Bundle; import android.widget.Button; import android.widget.LinearLayout; import android.widget.TextView;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b){super.onCreate(b);
  LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(40,60,40,40);
  TextView t=new TextView(this); t.setText("BLAY 2.1\nAsisten suara online"); t.setTextSize(24); l.addView(t);
  Button start=new Button(this); start.setText("Aktifkan BLAY"); l.addView(start);
  Button stop=new Button(this); stop.setText("Matikan BLAY"); l.addView(stop); setContentView(l);
  if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},10);
  start.setOnClickListener(v->{try{startForegroundService(new Intent(this,BlayStandbyService.class).setAction("ON"));}catch(Exception e){}}); 
  stop.setOnClickListener(v->{stopService(new Intent(this,BlayStandbyService.class));});
 }
}
