plugins { id("com.android.application") }
android { namespace = "com.blay.assistant"; compileSdk = 35
    defaultConfig { applicationId = "com.blay.assistant"; minSdk = 26; targetSdk = 35; versionCode = 21; versionName = "2.1" }
}
