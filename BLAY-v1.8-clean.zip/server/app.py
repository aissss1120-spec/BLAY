from fastapi import FastAPI

app = FastAPI(title="BLAY Server", version="1.8.0")

@app.get("/health")
def health():
    return {"ok": True, "service": "blay-server", "version": "1.8.0"}

@app.get("/v1/models/status")
def models_status():
    return {
        "router": "online",
        "models": ["qwen2.5-7b", "sahabatai-8b", "phi-3.5-mini"],
        "note": "Endpoint model belum dipasang pada clean build ini."
    }

@app.post("/v1/command")
def command(payload: dict):
    text = str(payload.get("text", "")).strip()
    return {"assistant": "BLAY", "text": f"Perintah diterima: {text}"}
