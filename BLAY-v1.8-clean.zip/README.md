# BLAY v1.8 — Clean Build

Clean Android + server foundation intended to remove the Gradle/SDK workflow errors.

## Android
- Native Android application
- `compileSdk 35`
- `targetSdk 35`
- `minSdk 26`
- AGP 8.7.3
- Gradle 8.9 in GitHub Actions
- Java 17
- Foreground microphone service foundation

## GitHub Actions
The workflow intentionally does **not** use the `packages:` input of `android-actions/setup-android`.
It installs `platform-tools`, `platforms;android-35`, and `build-tools;35.0.0` explicitly with `sdkmanager`.

After a push to `main`/`master`, or manual **Run workflow**, it builds:
`app/build/outputs/apk/debug/app-debug.apk`

## Important
This ZIP is a clean build baseline. The real BLAY wake-word model, online AI router connections, Owner/Client security, and production server authentication are not claimed as complete here.
