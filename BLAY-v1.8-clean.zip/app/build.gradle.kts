plugins {
    id("com.android.application")
}

android {
    namespace = "com.blay.assistant"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.blay.assistant"
        minSdk = 26
        targetSdk = 35
        versionCode = 18
        versionName = "1.8.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
}
