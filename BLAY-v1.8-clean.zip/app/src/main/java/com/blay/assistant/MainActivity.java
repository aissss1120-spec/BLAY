package com.blay.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(40, 60, 40, 40);

        TextView title = new TextView(this);
        title.setText("BLAY\nOnline Voice Assistant");
        title.setTextSize(26);
        root.addView(title);

        TextView status = new TextView(this);
        status.setText("Build v1.8.0 — clean Android foundation");
        status.setTextSize(16);
        root.addView(status);

        Button start = new Button(this);
        start.setText("Aktifkan Standby");
        start.setOnClickListener(v -> startStandby());
        root.addView(start);

        Button stop = new Button(this);
        stop.setText("Matikan Standby");
        stop.setOnClickListener(v -> stopService(new Intent(this, BlayStandbyService.class)));
        root.addView(stop);

        setContentView(root);
    }

    private void startStandby() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        Intent intent = new Intent(this, BlayStandbyService.class);
        startForegroundService(intent);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_AUDIO && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startStandby();
        }
    }
}
