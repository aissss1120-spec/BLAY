package com.blay.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int MIC = 10;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(40, 60, 40, 40);

        Button on = new Button(this);
        on.setText("Aktifkan BLAY");
        Button off = new Button(this);
        off.setText("Matikan BLAY");

        box.addView(on);
        box.addView(off);
        setContentView(box);

        on.setOnClickListener(v -> {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC);
            } else {
                startService();
            }
        });
        off.setOnClickListener(v -> stopService(new Intent(this, BlayStandbyService.class)));
    }

    private void startService() {
        Intent i = new Intent(this, BlayStandbyService.class);
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
        Toast.makeText(this, "BLAY aktif dan siap mendengar", Toast.LENGTH_SHORT).show();
    }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r,p,g);
        if (r == MIC && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) startService();
    }
}
