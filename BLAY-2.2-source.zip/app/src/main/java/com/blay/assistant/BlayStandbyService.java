package com.blay.assistant;

import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.speech.*;
import android.speech.tts.TextToSpeech;
import android.view.*;
import android.net.Uri;
import java.util.*;

public class BlayStandbyService extends Service implements TextToSpeech.OnInitListener {
    private static final String CH = "blay";
    private SpeechRecognizer recognizer;
    private Intent speechIntent;
    private TextToSpeech tts;
    private boolean stopping = false;
    private Handler handler = new Handler(Looper.getMainLooper());

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        startForeground(2202, notification());
        tts = new TextToSpeech(this, this);
        speechIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID");
        speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "id-ID");
        speechIntent.putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, "id-ID");
        speechIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        speechIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        prepareRecognizer();
    }

    private void prepareRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("Pengenalan suara tidak tersedia di perangkat ini.");
            return;
        }
        if (recognizer != null) {
            try { recognizer.destroy(); } catch(Exception ignored) {}
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle b) {}
            public void onBeginningOfSpeech() {}
            public void onRmsChanged(float r) {}
            public void onBufferReceived(byte[] b) {}
            public void onEndOfSpeech() { scheduleListen(350); }
            public void onError(int e) { scheduleListen(700); }
            public void onResults(Bundle b) {
                ArrayList<String> x = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (x != null && !x.isEmpty()) handle(x.get(0));
                else scheduleListen(350);
            }
            public void onPartialResults(Bundle b) {}
            public void onEvent(int a, Bundle b) {}
        });
    }

    private void scheduleListen(long ms) {
        if (!stopping) handler.postDelayed(this::listen, ms);
    }

    private void listen() {
        if (stopping || recognizer == null) return;
        try { recognizer.startListening(speechIntent); }
        catch(Exception e) { prepareRecognizer(); scheduleListen(1000); }
    }

    private void handle(String raw) {
        String q = raw == null ? "" : raw.trim();
        if (q.isEmpty()) { scheduleListen(300); return; }
        String l = q.toLowerCase(Locale.ROOT);

        if (l.equals("berhenti") || l.equals("matikan blay") || l.equals("stop blay")) {
            speak("Baik, BLAY berhenti.");
            stopping = true;
            handler.postDelayed(() -> stopSelf(), 1200);
            return;
        }
        if (l.contains("youtube")) {
            speak("Membuka YouTube.");
            openPackageOrUrl("com.google.android.youtube", "https://www.youtube.com");
            return;
        }
        if (l.contains("maps") || l.contains("google maps")) {
            speak("Membuka Google Maps.");
            openPackageOrUrl("com.google.android.apps.maps", "https://maps.google.com");
            return;
        }
        if (l.startsWith("cari ") || l.startsWith("search ")) {
            String term = q.substring(q.indexOf(" ") + 1).trim();
            speak("Saya cari " + term);
            openUrl("https://www.google.com/search?q=" + Uri.encode(term));
            return;
        }
        if (l.startsWith("buka ")) {
            String app = q.substring(5).trim();
            if (tryOpenApp(app)) { speak("Membuka " + app); return; }
            speak("Saya cari " + app);
            openUrl("https://www.google.com/search?q=" + Uri.encode(app));
            return;
        }

        speak("Saya mendengar " + q);
    }

    private boolean tryOpenApp(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        String[] pkgs;
        if (n.contains("whatsapp")) pkgs = new String[]{"com.whatsapp"};
        else if (n.contains("chrome")) pkgs = new String[]{"com.android.chrome","com.google.android.apps.chrome"};
        else if (n.contains("kamera") || n.contains("camera")) pkgs = new String[]{"com.android.camera2","com.google.android.GoogleCamera"};
        else return false;
        for (String p : pkgs) {
            try {
                Intent i = getPackageManager().getLaunchIntentForPackage(p);
                if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); return true; }
            } catch(Exception ignored) {}
        }
        return false;
    }

    private void openPackageOrUrl(String pkg, String url) {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
            if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); return; }
        } catch(Exception ignored) {}
        openUrl(url);
    }

    private void openUrl(String u) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(u));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch(Exception ignored) {}
    }

    private void speak(String s) {
        if (tts != null) tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "blay");
    }

    @Override public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            tts.setLanguage(new Locale("id","ID"));
            handler.postDelayed(this::listen, 700);
        }
    }

    @Override public int onStartCommand(Intent i, int flags, int id) {
        stopping = false;
        return START_STICKY;
    }

    @Override public void onDestroy() {
        stopping = true;
        handler.removeCallbacksAndMessages(null);
        if (recognizer != null) { try { recognizer.stopListening(); recognizer.destroy(); } catch(Exception ignored) {} }
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    private void createChannel() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CH, "BLAY", NotificationManager.IMPORTANCE_LOW));
    }

    private Notification notification() {
        return new Notification.Builder(this, CH)
            .setContentTitle("BLAY aktif")
            .setContentText("BLAY sedang mendengarkan")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build();
    }

    @Override public IBinder onBind(Intent i) { return null; }
}
