import os
from fastapi import FastAPI
from pydantic import BaseModel
import httpx

app=FastAPI(title="BLAY Server")
QWEN=os.getenv("QWEN_URL","")
SAHABAT=os.getenv("SAHABAT_URL","")
PHI=os.getenv("PHI_URL","")

class Command(BaseModel):
    command:str
    device_id:str|None=None

def local_action(cmd:str):
    c=cmd.lower()
    if "youtube" in c: return "youtube", "Membuka YouTube."
    if "maps" in c or "peta" in c: return "maps", "Membuka Maps."
    if "pengaturan" in c or "setting" in c: return "settings", "Membuka pengaturan."
    if c.startswith("buka ") and ("http://" in c or "https://" in c): return "browser "+c[5:], "Membuka browser."
    return "", None

async def ask(url, cmd):
    if not url: return None
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            r=await client.post(url,json={"prompt":cmd,"messages":[{"role":"user","content":cmd}]})
            return r.json()
    except Exception:
        return None

@app.get("/health")
def health(): return {"ok":True,"service":"BLAY"}

@app.post("/v1/command")
async def command(c:Command):
    action,reply=local_action(c.command)
    if action: return {"reply":reply,"action":action,"router":"local"}
    for name,url in [("qwen",QWEN),("sahabatai",SAHABAT),("phi",PHI)]:
        data=await ask(url,c.command)
        if data:
            text=data.get("reply") or data.get("text") or data.get("response") or "Perintah diterima."
            return {"reply":text,"action":"","router":name}
    return {"reply":f"Saya menerima: {c.command}","action":"","router":"fallback"}
