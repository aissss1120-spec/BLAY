package com.blay.assistant;

import android.Manifest;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText serverUrl;
    TextView status;
    Button start, stop, test;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        serverUrl=findViewById(R.id.serverUrl); status=findViewById(R.id.status);
        start=findViewById(R.id.start); stop=findViewById(R.id.stop); test=findViewById(R.id.test);
        serverUrl.setText(getPreferences(0).getString("server","http://10.0.2.2:8000"));
        if (Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS},100);
        start.setOnClickListener(v -> {
            getPreferences(0).edit().putString("server",serverUrl.getText().toString().trim()).apply();
            Intent i=new Intent(this,BlayStandbyService.class).setAction("START");
            i.putExtra("server",serverUrl.getText().toString().trim());
            if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
            status.setText("Standby aktif — ucapkan: Blay");
        });
        stop.setOnClickListener(v -> { stopService(new Intent(this,BlayStandbyService.class)); status.setText("Standby mati"); });
        test.setOnClickListener(v -> {
            Intent i=new Intent(this,BlayStandbyService.class).setAction("TEST");
            i.putExtra("server",serverUrl.getText().toString().trim());
            if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
            status.setText("Tes perintah dikirim...");
        });
    }
}
