package com.blay.assistant;

import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.speech.*;
import android.speech.tts.TextToSpeech;
import android.view.*;\nimport android.net.Uri;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.*;
import org.json.*;

public class BlayStandbyService extends Service {
    static final int NOTIF=20;
    SpeechRecognizer sr; Intent recognizerIntent; TextToSpeech tts; Handler h;
    String server="http://10.0.2.2:8000"; boolean active=false; boolean commandMode=false;

    @Override public void onCreate(){
        super.onCreate(); h=new Handler(Looper.getMainLooper());
        createChannel();
        tts=new TextToSpeech(this,s-> { if(s==TextToSpeech.SUCCESS) tts.setLanguage(new Locale("id","ID"));});
    }
    void createChannel(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel c=new NotificationChannel("blay","BLAY Standby",NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }
    Notification notification(){
        Intent i=new Intent(this,MainActivity.class);
        PendingIntent p=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this,"blay").setContentTitle("BLAY aktif")
            .setContentText(commandMode?"Mendengarkan perintah":"Menunggu kata Blay")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentIntent(p).build();
    }
    @Override public int onStartCommand(Intent i,int flags,int id){
        if(i!=null && i.getStringExtra("server")!=null) server=i.getStringExtra("server");
        if("TEST".equals(i==null?null:i.getAction())) { startForeground(NOTIF,notification()); new Thread(()->sendCommand("tes")).start(); return START_NOT_STICKY; }
        if("START".equals(i==null?null:i.getAction())) startStandby();
        return START_STICKY;
    }
    void startStandby(){
        active=true; startForeground(NOTIF,notification()); h.post(this::listen);
    }
    void listen(){
        if(!active) return;
        if(sr!=null) { try{sr.destroy();}catch(Exception e){} }
        sr=SpeechRecognizer.createSpeechRecognizer(this);
        sr.setRecognitionListener(new RecognitionListener(){
            public void onReadyForSpeech(Bundle b){}
            public void onBeginningOfSpeech(){commandMode=true;}
            public void onRmsChanged(float r){}
            public void onBufferReceived(byte[] b){}
            public void onEndOfSpeech(){}
            public void onError(int e){ commandMode=false; h.postDelayed(BlayStandbyService.this::listen,700);}
            public void onResults(Bundle b){
                ArrayList<String> a=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                String text=(a==null||a.isEmpty())?"":a.get(0).trim();
                handle(text); commandMode=false;
            }
            public void onPartialResults(Bundle b){}
            public void onEvent(int t,Bundle b){}
        });
        recognizerIntent=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"id-ID");
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,false);
        sr.startListening(recognizerIntent);
    }
    void handle(String text){
        if(text.isEmpty()){h.postDelayed(this::listen,500);return;}
        String l=text.toLowerCase(Locale.ROOT);
        if(!commandMode && !l.contains("blay")) {h.postDelayed(this::listen,500);return;}
        if(l.contains("blay")){
            String cmd=l.replace("blay","").trim();
            if(cmd.isEmpty()){speak("Ya, saya mendengarkan."); commandMode=true; h.postDelayed(this::listen,1200); return;}
            new Thread(()->sendCommand(cmd)).start();
        } else new Thread(()->sendCommand(text)).start();
    }
    void sendCommand(String cmd){
        try{
            JSONObject o=new JSONObject(); o.put("command",cmd); o.put("device_id",Build.MANUFACTURER+"-"+Build.MODEL);
            URL u=new URL(server.replaceAll("/$","")+"/v1/command");
            HttpURLConnection c=(HttpURLConnection)u.openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(7000); c.setReadTimeout(15000); c.setDoOutput(true);
            c.setRequestProperty("Content-Type","application/json");
            c.getOutputStream().write(o.toString().getBytes(StandardCharsets.UTF_8));
            String body=new BufferedReader(new InputStreamReader(c.getInputStream(),StandardCharsets.UTF_8)).lines().reduce("",(x,y)->x+y);
            JSONObject r=new JSONObject(body); String reply=r.optString("reply","Perintah diterima."); String action=r.optString("action","");
            h.post(()->{speak(reply); executeAction(action); h.postDelayed(this::listen,1200);});
        }catch(Exception e){h.post(()->{speak("Server BLAY belum terhubung.");h.postDelayed(this::listen,1500);});}
    }
    void executeAction(String action){
        if(action==null||action.isEmpty())return;
        try{
            Intent in;
            if(action.startsWith("youtube")) in=getPackageManager().getLaunchIntentForPackage("com.google.android.youtube");
            else if(action.startsWith("maps")) in=new Intent(Intent.ACTION_VIEW,Uri.parse("geo:0,0?q="+Uri.encode(action.substring(5).trim())));
            else if(action.startsWith("settings")) in=new Intent(android.provider.Settings.ACTION_SETTINGS);
            else if(action.startsWith("browser")) in=new Intent(Intent.ACTION_VIEW,Uri.parse(action.substring(7).trim().isEmpty()?"https://www.google.com":action.substring(7).trim()));
            else return;
            if(in!=null) in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); if(in!=null) startActivity(in);
        }catch(Exception ignored){}
    }
    void speak(String s){ if(tts!=null) tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"blay");}
    @Override public void onDestroy(){active=false;if(sr!=null)sr.destroy();if(tts!=null)tts.shutdown();super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
