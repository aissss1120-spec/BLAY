# BLAY 2.0

Android voice assistant client + FastAPI router server.

## Android
1. Build with GitHub Actions.
2. Install the debug APK.
3. Grant microphone and notification permission.
4. Enter the BLAY server URL.
5. Tap AKTIFKAN STANDBY.
6. Say "Blay buka YouTube", "Blay buka Maps", etc.

## Important
This build uses Android SpeechRecognizer for the voice loop. It is a functional prototype, but it is **not** an offline wake-word engine. A true local "Blay" wake word requires a trained on-device wake-word model (for example an openWakeWord/TFLite model) packaged in `assets/`.

The server provides local command actions and configurable endpoints for Qwen, SahabatAI and Phi. Configure the endpoint environment variables before deploying.
