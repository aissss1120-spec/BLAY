package com.blay.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int MIC = 10;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView terminal;
    private Button on;
    private Button off;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        buildTerminalUI();
        runBootSequence();
    }

    private void buildTerminalUI() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 34, 28, 24);
        root.setBackgroundColor(Color.BLACK);

        TextView title = new TextView(this);
        title.setText("B L A Y   //   SYSTEM CONSOLE");
        title.setTextColor(Color.rgb(0, 255, 120));
        title.setTextSize(18);
        title.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, 55));

        ScrollView scroll = new ScrollView(this);
        terminal = new TextView(this);
        terminal.setTextColor(Color.rgb(0, 255, 120));
        terminal.setTextSize(13);
        terminal.setTypeface(Typeface.MONOSPACE);
        terminal.setPadding(10, 12, 10, 12);
        terminal.setGravity(Gravity.BOTTOM);
        scroll.addView(terminal);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        on = new Button(this);
        on.setText("> AKTIFKAN BLAY");
        on.setTextColor(Color.BLACK);
        on.setTextSize(14);
        on.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        on.setBackgroundColor(Color.rgb(0, 255, 120));

        off = new Button(this);
        off.setText("> MATIKAN BLAY");
        off.setTextColor(Color.rgb(0, 255, 120));
        off.setTextSize(14);
        off.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        off.setBackgroundColor(Color.rgb(25, 25, 25));

        root.addView(on, new LinearLayout.LayoutParams(-1, 55));
        root.addView(off, new LinearLayout.LayoutParams(-1, 55));
        setContentView(root);

        on.setOnClickListener(v -> {
            printLine(">> REQUEST: START VOICE SERVICE");
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC);
            } else {
                startService();
            }
        });

        off.setOnClickListener(v -> {
            stopService(new Intent(this, BlayStandbyService.class));
            printLine("[OK] BLAY SERVICE STOPPED");
            Toast.makeText(this, "BLAY dimatikan", Toast.LENGTH_SHORT).show();
        });
    }

    private void runBootSequence() {
        String[] lines = {
            "",
            "[BOOT] BLAY 2.3 INITIALIZING...",
            "[SCAN] Android runtime ........ OK",
            "[SCAN] Audio subsystem ........ OK",
            "[SCAN] Speech engine ......... READY",
            "[SCAN] Indonesian voice ...... READY",
            "[SCAN] Command interface ..... READY",
            "[LINK] Standby service ....... READY",
            "",
            "> BLAY SYSTEM READY",
            "> Awaiting operator command...",
            ""
        };
        terminal.setText("");
        for (int i = 0; i < lines.length; i++) {
            final String line = lines[i];
            handler.postDelayed(() -> printLine(line), i * 220L);
        }
    }

    private void printLine(String line) {
        if (terminal == null) return;
        terminal.append(line + "\n");
        terminal.post(() -> {
            View parent = (View) terminal.getParent();
            if (parent instanceof ScrollView) ((ScrollView) parent).fullScroll(View.FOCUS_DOWN);
        });
    }

    private void startService() {
        Intent i = new Intent(this, BlayStandbyService.class);
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
        printLine("[OK] VOICE SERVICE ONLINE");
        printLine("[LISTEN] BLAY sedang mendengar...");
        Toast.makeText(this, "BLAY aktif dan siap mendengar", Toast.LENGTH_SHORT).show();
    }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r, p, g);
        if (r == MIC && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) {
            printLine("[OK] MICROPHONE ACCESS GRANTED");
            startService();
        } else if (r == MIC) {
            printLine("[ERROR] MICROPHONE ACCESS DENIED");
        }
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
