plugins { id("com.android.application") }

android {
    namespace = "com.blay.assistant"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.blay.assistant"
        minSdk = 26
        targetSdk = 35
        versionCode = 23
        versionName = "2.3"
    }

    signingConfigs {
        create("blayDebug") {
            storeFile = file("../blay-debug.keystore")
            storePassword = "blaydebug"
            keyAlias = "blay"
            keyPassword = "blaydebug"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("blayDebug")
        }
    }
}
