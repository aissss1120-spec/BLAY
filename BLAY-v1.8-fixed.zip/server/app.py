from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="BLAY v1.8 Server")

class Command(BaseModel):
    text: str

@app.get("/health")
def health():
    return {"ok": True, "version": "1.8.0"}

@app.get("/v1/models/status")
def models_status():
    return {
        "router": "online",
        "models": {
            "qwen2.5-7b": "not-configured",
            "sahabatai-8b": "not-configured",
            "phi-3.5-mini": "not-configured",
        }
    }

@app.post("/v1/command")
def command(req: Command):
    return {
        "assistant": "BLAY",
        "text": f"Perintah diterima: {req.text}",
        "model": "router-placeholder",
        "action": None
    }
