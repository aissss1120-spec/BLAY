# BLAY v1.8

BLAY Android client + online backend prototype.

## Build
GitHub Actions workflow:
`.github/workflows/build-blay.yml`

The Android project is now a normal Gradle multi-project build:
- `settings.gradle.kts`
- root `build.gradle.kts`
- `app/build.gradle.kts`
- `app/src/main/...`

## Important
This version is a buildable foundation. The custom "Blay" wake-word model and production AI model endpoints are not bundled yet.
